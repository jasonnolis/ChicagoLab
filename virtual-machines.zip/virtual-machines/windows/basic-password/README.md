## Example: Basic Windows Virtual Machine

This example provisions a basic Windows Virtual Machine
