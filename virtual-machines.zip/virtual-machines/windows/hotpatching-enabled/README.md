## Example: Windows Virtual Machine with Automatic VM Guest Patching and Hotpatching Enabled

This example provisions a Windows Virtual Machine with Automatic VM Guest Patching and Hotpatching Enabled.
