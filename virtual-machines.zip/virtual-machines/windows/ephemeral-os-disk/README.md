## Example: Windows Virtual Machine with an Ephemeral OS Disk

This example provisions a Windows Virtual Machine with an Ephemeral OS Disk.
