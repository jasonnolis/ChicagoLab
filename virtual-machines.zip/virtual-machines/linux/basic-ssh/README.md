## Example: Basic Linux Virtual Machine

This example provisions a basic Linux Virtual Machine using your SSH key for authentication.

Note: this assumes you have a Public SSH Key available at `~/.ssh/id_rsa.pub`
