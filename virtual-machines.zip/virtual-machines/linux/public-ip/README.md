## Example: Basic Linux Virtual Machine

This example provisions a basic Linux Virtual Machine with a Public IP and a Network Security Group
