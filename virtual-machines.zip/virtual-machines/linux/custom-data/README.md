## Example: Linux Virtual Machine with Custom Data

This example provisions a Linux Virtual Machine with some Custom Data.
