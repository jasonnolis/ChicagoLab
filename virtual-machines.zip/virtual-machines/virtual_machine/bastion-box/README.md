## Example: A Bastion Box

This example provisions a Bastion Box, which is located in its own Subnet with a Public IP Address - which has SSH access to the other internal subnets (in this case a placeholder `web` subnet).
