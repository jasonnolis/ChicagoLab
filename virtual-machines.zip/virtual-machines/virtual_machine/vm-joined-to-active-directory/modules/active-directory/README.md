## Module: Active Directory

This module is designed to quickly spin up an Active Directory Forest on a single node, this is **by no means best practice** and we'd **highly recommend** not using this approach in Production.

This module was based on / heavily inspired by: https://github.com/bobalob/Terraform-AzureRM-Example/tree/winrm-https
