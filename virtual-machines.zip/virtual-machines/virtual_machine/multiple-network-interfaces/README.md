## Example: Virtual Machine with Multiple Network Interfaces

This example provisions a Virtual Machine with multiple Network Interfaces, one attached to the Internal network and one attached to a separate External network (which has a Network Security Group to selectively open certain ports).
