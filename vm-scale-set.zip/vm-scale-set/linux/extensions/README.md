## Example: Linux Virtual Machine Scale Set with VM Extensions

This example provisions a basic Linux Virtual Machine Scale Set using a password for authentication and a `CustomScript` extension.
