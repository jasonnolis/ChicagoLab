## Example: Linux Virtual Machine Scale Set with a Rolling Upgrade Policy

This example provisions a Linux Virtual Machine Scale Set using a password for authentication with a Rolling Upgrade Policy.
