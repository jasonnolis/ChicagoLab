## Example: Linux Virtual Machine Scale Set with Custom Data

This example provisions a Linux Virtual Machine Scale Set using a password for authentication with Custom Data.
