## Example: Spot Instance Linux Virtual Machine Scale Set

This example provisions a Spot Instance Linux Virtual Machine Scale Set using a password for authentication.
