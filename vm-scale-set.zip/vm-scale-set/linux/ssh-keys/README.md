## Example: Linux Virtual Machine Scale Set using SSH Public Keys for authentication

This example provisions a Linux Virtual Machine Scale Set using SSH Public Key authentication.
