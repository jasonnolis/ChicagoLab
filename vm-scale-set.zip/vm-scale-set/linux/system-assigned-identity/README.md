## Example: Linux Virtual Machine Scale Set with a System-Assigned Managed Identity

This example provisions a Linux Virtual Machine Scale Set using a password for authentication which has a System Assigned Managed Identity.
