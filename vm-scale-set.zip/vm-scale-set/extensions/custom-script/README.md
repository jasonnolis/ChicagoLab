## Example: Custom Script Extension

This example configures a Custom Script Extension on a Linux Virtual Machine Scale Set - however the example is essentially the same for a Windows Virtual Machine Scale Sets too.
