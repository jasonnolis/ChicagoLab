## Example: Virtual Machine Scale Set with Auto Scale Rules configured

This example provisions a Virtual Machine Scale Set with Managed Disks and an Auto Scale Rule configured.
