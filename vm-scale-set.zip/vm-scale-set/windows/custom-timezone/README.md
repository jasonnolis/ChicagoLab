## Example: Windows Virtual Machine Scale Set with a custom TimeZone

This example provisions a Windows Virtual Machine Scale Set with a custom TimeZone.
