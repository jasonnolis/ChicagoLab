## Example: Windows Virtual Machine Scale Set with VM Extensions

This example provisions a basic Windows Virtual Machine Scale Set with two VM Extensions.
