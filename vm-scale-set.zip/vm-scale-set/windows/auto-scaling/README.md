## Example: Windows Virtual Machine Scale Set with Auto-Scaling

This example provisions a Windows Virtual Machine Scale Set with Auto-Scaling Configured.
