## Example: Windows Virtual Machine Scale Set with a Hybrid Use Benefit Discount

This example provisions a Windows Virtual Machine Scale Set with a Hybrid Use Benefit Discount.

This assumes that you have an existing Windows Client/Server license which qualifies for the Hybrid Use Discount - more information can be found here: https://docs.microsoft.com/en-us/azure/virtual-machines/windows/hybrid-use-benefit-licensing
